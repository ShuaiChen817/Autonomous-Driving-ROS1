#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CameraInfo.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud2_iterator.h>
#include <cv_bridge/cv_bridge.h>
#include <image_geometry/pinhole_camera_model.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>

class DepthToPointCloud {
public:
    DepthToPointCloud() {
        ros::NodeHandle nh;
        image_sub_ = nh.subscribe("/Unity_ROS_message_Rx/OurCar/Sensors/DepthCamera/image_raw", 1, &DepthToPointCloud::imageCallback, this);
        info_sub_ = nh.subscribe("/Unity_ROS_message_Rx/OurCar/Sensors/DepthCamera/camera_info", 1, &DepthToPointCloud::infoCallback, this);
        pc_pub_ = nh.advertise<sensor_msgs::PointCloud2>("/DepthCamera/points", 1);
    }

    void infoCallback(const sensor_msgs::CameraInfoConstPtr& info_msg) {
        if (!camera_model_initialized_) {
            camera_model_.fromCameraInfo(info_msg);
            camera_model_initialized_ = true;
            ROS_INFO("Camera model initialized.");
        }
    }

    void imageCallback(const sensor_msgs::ImageConstPtr& image_msg) {
        if (!camera_model_initialized_) {
            ROS_WARN_THROTTLE(5, "Waiting for camera_info...");
            return;
        }
        cv_bridge::CvImagePtr cv_ptr;
        try {
            cv_ptr = cv_bridge::toCvCopy(image_msg, image_msg->encoding);
        } catch (cv_bridge::Exception& e) {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }
        cv::Mat depth = cv_ptr->image;
        sensor_msgs::PointCloud2 cloud_msg;
        cloud_msg.header = image_msg->header;
        cloud_msg.header.frame_id = "OurCar/Sensors/DepthCamera";
        sensor_msgs::PointCloud2Modifier modifier(cloud_msg);
        modifier.setPointCloud2FieldsByString(1, "xyz");
        modifier.resize(depth.rows * depth.cols);

        sensor_msgs::PointCloud2Iterator<float> iter_x(cloud_msg, "x");
        sensor_msgs::PointCloud2Iterator<float> iter_y(cloud_msg, "y");
        sensor_msgs::PointCloud2Iterator<float> iter_z(cloud_msg, "z");

        for (int v = 0; v < depth.rows; ++v) {
            for (int u = 0; u < depth.cols; ++u, ++iter_x, ++iter_y, ++iter_z) {
                float d = depth.at<uint16_t>(v, u) * 0.001;
                if (d > 0.1 && d < 10.0) {
                    cv::Point3d xyz = camera_model_.projectPixelTo3dRay(cv::Point2d(u, v));
                    *iter_x = xyz.x * d;
                    *iter_y = xyz.y * d;
                    *iter_z = xyz.z * d;
                } else {
                    *iter_x = *iter_y = *iter_z = std::numeric_limits<float>::quiet_NaN();
                }
            }
        }
        pc_pub_.publish(cloud_msg);
    }

private:
    ros::Subscriber image_sub_;
    ros::Subscriber info_sub_;
    ros::Publisher pc_pub_;
    image_geometry::PinholeCameraModel camera_model_;
    bool camera_model_initialized_ = false;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "depth_to_pointcloud_node");
    DepthToPointCloud node;
    ros::spin();
    return 0;
}
